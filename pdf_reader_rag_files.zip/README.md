# PDF Reader RAG (free starter project)

A lightweight PDF question-answering app built with Streamlit. Upload **one PDF**, ask a question, retrieve relevant passages, and view the source pages.

## What is included

- `app.py` — the complete Streamlit application.
- TF-IDF retrieval using scikit-learn (runs without a paid embedding service).
- PDF text extraction using PyMuPDF.
- Optional Gemini generation using an API key stored in Streamlit Secrets.
- Evidence passages and page numbers to help check answers.
- A clear warning that similarity scores are **not true answer accuracy**.

## Important accuracy limitation

A single PDF does not, by itself, tell us the true accuracy of generated answers. A genuine accuracy evaluation needs a test set of questions and verified reference answers (or expert human review). The app shows retrieval relevance scores as diagnostic signals only; they are **not** the probability that an answer is correct.

For a basic evaluation, prepare 10–30 questions whose answers you can verify in the PDF. Record whether each answer is correct, partly correct, unsupported, or missing a citation. Then calculate:

`Answer accuracy = number of fully correct answers / total test questions × 100`

Do not call the TF-IDF relevance percentage “accuracy.”

## Free tools used

- GitHub: store the code.
- Streamlit Community Cloud: host the app on its free tier, subject to current usage and resource limits.
- Python packages: Streamlit, PyMuPDF, scikit-learn.
- Optional: Google AI Studio / Gemini API free tier, if available for your account and region. Free-tier limits and model availability can change. The app still runs without a key, in evidence-only mode.

## Run locally

Use Python 3.10 or newer.

1. Install Python from https://www.python.org/downloads/
2. Create a folder and save `app.py` in it.
3. Open a terminal in that folder.
4. Install dependencies:

   ```bash
   pip install streamlit pymupdf scikit-learn google-genai
   ```

5. Start the app:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL shown in the terminal (usually `http://localhost:8501`).

If you do not want Gemini generation, `google-genai` can be omitted. The app will show relevant PDF passages instead of composing a generated answer.

## Publish to GitHub

1. Sign in at https://github.com/ and create a **new public repository** (for example, `pdf-reader-rag`). Public is easiest for the free Streamlit Community Cloud workflow.
2. On the repository page, choose **Add file → Create new file**.
3. Name the file `app.py`, paste in the complete code from this project’s `app.py`, and commit it.
4. Add another file named `requirements.txt` with exactly these lines:

   ```text
   streamlit
   pymupdf
   scikit-learn
   google-genai
   ```

   (The two downloadable project files are `app.py` and this instruction file; `requirements.txt` is a small additional deployment file that Streamlit needs to install dependencies.)
5. Commit the new file. Do not upload private PDFs or API keys to the repository.

## Deploy on Streamlit Community Cloud

1. Open https://share.streamlit.io/ and sign in using GitHub.
2. Choose **Create app** / **Deploy an app**.
3. Select your repository, branch (usually `main`), and main file path `app.py`.
4. Deploy. The first build may take a few minutes.
5. Open the deployed app URL and test with a non-sensitive, text-based PDF.

### Add the optional Gemini API key securely

1. Open https://aistudio.google.com/app/apikey and check whether you can create a key under the free tier in your account/region.
2. In Streamlit Community Cloud, open your app’s **Settings → Secrets**.
3. Add this TOML entry:

   ```toml
   GEMINI_API_KEY = "paste-your-key-here"
   ```

4. Save secrets and reboot/redeploy the app if prompted.
5. Never place the key in `app.py`, GitHub commits, screenshots, or public messages.

The code uses `gemini-2.5-flash` as an example model name. If the API says the model is unavailable to your account, check the current model list in Google AI Studio and update the model name in `app.py`.

## How to use

1. Upload exactly one PDF in the app.
2. Enter a specific question.
3. Select **Get answer**.
4. Check the answer against the cited page numbers and the displayed retrieved passages.
5. If the app says it cannot find enough evidence, try alternative wording or check whether the PDF is scanned.

## Known limitations

- Scanned/image-only PDFs are not supported by this starter app; it needs selectable text. OCR can be added later with a free OCR tool such as Tesseract, but hosting setup becomes more involved.
- Retrieval uses TF-IDF keyword matching, not semantic embeddings. It is lightweight and easy to understand for a first RAG project, but may miss paraphrases or concepts expressed with different words.
- Model output can still be wrong. Always inspect citations and source passages.
- Do not upload confidential documents unless you understand the hosting provider’s data handling terms.
- Free hosting and API tiers can have limits or change over time.

## Troubleshooting

- **`ModuleNotFoundError`**: check that all packages appear in `requirements.txt`, then redeploy.
- **No text found**: the PDF is probably scanned or image-only. Use a text-based PDF or add OCR.
- **No relevant passages**: ask with words used in the document, or increase the number of retrieved passages.
- **Gemini error**: verify the secret name is exactly `GEMINI_API_KEY`, check model availability, and review your account's current free-tier quota.
