import os
import re
from typing import List, Dict

import streamlit as st
import fitz  # PyMuPDF
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Optional free-tier Gemini API. The app still works in evidence-only mode without a key.
try:
    from google import genai
except Exception:
    genai = None

st.set_page_config(page_title="PDF Reader RAG", page_icon="📄", layout="wide")
st.title("📄 PDF Reader RAG")
st.caption("Ask questions about one PDF. Answers are grounded in retrieved passages and show evidence.")

st.info(
    "Accuracy note: this app reports a retrieval/evidence indicator, not a scientifically measured "
    "answer-accuracy percentage. True accuracy requires a set of questions with verified reference answers."
)

def clean_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

def extract_pdf(uploaded_file) -> List[Dict]:
    doc = fitz.open(stream=uploaded_file.getvalue(), filetype="pdf")
    pages = []
    for page_num, page in enumerate(doc, start=1):
        text = clean_text(page.get_text("text"))
        if text:
            pages.append({"page": page_num, "text": text})
    return pages

def chunk_pages(pages: List[Dict], chunk_words: int = 180, overlap: int = 35) -> List[Dict]:
    chunks = []
    for p in pages:
        words = p["text"].split()
        if not words:
            continue
        start = 0
        while start < len(words):
            end = min(start + chunk_words, len(words))
            chunks.append({
                "page": p["page"],
                "text": " ".join(words[start:end])
            })
            if end == len(words):
                break
            start = max(end - overlap, start + 1)
    return chunks

def retrieve(question: str, chunks: List[Dict], top_k: int = 4):
    texts = [c["text"] for c in chunks]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(texts + [question])
    similarities = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
    best = similarities.argsort()[::-1][:min(top_k, len(chunks))]
    return [(chunks[i], float(similarities[i])) for i in best if similarities[i] > 0]

def build_prompt(question: str, results) -> str:
    evidence = "\n\n".join(
        f"[Page {chunk['page']} | relevance {score:.3f}]\n{chunk['text']}"
        for chunk, score in results
    )
    return f"""You are a careful PDF question-answering assistant.
Answer the user's question using ONLY the evidence below.
If the evidence does not contain the answer, say: "I couldn't find enough evidence in this PDF to answer confidently."
Do not invent facts. Keep the answer clear and concise. Cite supporting pages as [Page N].
Separate facts from any inference.

QUESTION:
{question}

PDF EVIDENCE:
{evidence}
"""

def evidence_only_answer(results):
    if not results:
        return "I couldn't find a relevant passage in the extracted PDF text. The PDF may be scanned, or the question may use different wording."
    parts = []
    for chunk, score in results:
        parts.append(f"- **Page {chunk['page']}** (retrieval relevance: {score:.2f}): {chunk['text']}")
    return "I don't have a configured generative model, so here are the most relevant passages instead of a generated answer:\n\n" + "\n\n".join(parts)

with st.sidebar:
    st.header("Settings")
    top_k = st.slider("Evidence passages to retrieve", min_value=1, max_value=8, value=4)
    st.markdown("**Free generation option**")
    st.write("Add a Gemini API key in Streamlit Secrets to enable generated answers. Without it, the app returns evidence passages only.")
    st.markdown("[Get a Gemini API key](https://aistudio.google.com/app/apikey)")
    st.caption("Free-tier availability, limits, and model names can change. Never publish your API key in source code.")

uploaded = st.file_uploader("Upload one PDF", type=["pdf"], accept_multiple_files=False)

if uploaded:
    try:
        pages = extract_pdf(uploaded)
        if not pages:
            st.error("No selectable text was found. This may be a scanned/image-only PDF. OCR is not included in this free starter version.")
            st.stop()

        chunks = chunk_pages(pages)
        st.success(f"Loaded **{uploaded.name}**: extracted text from {len(pages)} pages and created {len(chunks)} searchable chunks.")
        with st.expander("Preview extracted text"):
            st.write(pages[0]["text"][:4000] + ("…" if len(pages[0]["text"]) > 4000 else ""))

        question = st.text_input("Ask a question about this PDF", placeholder="e.g., What are the main conclusions?")
        if st.button("Get answer", type="primary", disabled=not question.strip()):
            results = retrieve(question.strip(), chunks, top_k=top_k)
            if not results:
                st.warning("No matching passages found. Try different wording or check whether the PDF contains selectable text.")
            else:
                # This is a heuristic evidence/retrieval indicator, not answer accuracy.
                top_score = results[0][1]
                avg_score = sum(score for _, score in results) / len(results)
                st.subheader("Answer")
                api_key = os.getenv("GEMINI_API_KEY", "")
                try:
                    api_key = st.secrets.get("GEMINI_API_KEY", api_key)
                except Exception:
                    # No Streamlit secrets file configured; environment variable may still be used.
                    pass
                if api_key and genai is not None:
                    try:
                        client = genai.Client(api_key=api_key)
                        prompt = build_prompt(question.strip(), results)
                        response = client.models.generate_content(
                            model="gemini-2.5-flash",
                            contents=prompt
                        )
                        answer = (response.text or "").strip()
                        if not answer:
                            answer = evidence_only_answer(results)
                        st.markdown(answer)
                    except Exception as e:
                        st.warning(f"Generation failed, so showing evidence passages instead. Details: {e}")
                        st.markdown(evidence_only_answer(results))
                else:
                    st.markdown(evidence_only_answer(results))

                st.subheader("Evidence & reliability indicators")
                c1, c2, c3 = st.columns(3)
                c1.metric("Top passage relevance", f"{top_score:.1%}")
                c2.metric("Average retrieved relevance", f"{avg_score:.1%}")
                c3.metric("Passages found", str(len(results)))
                st.caption(
                    "These percentages are TF-IDF similarity scores normalized for display. They are NOT the probability "
                    "that the answer is correct and should not be described as answer accuracy."
                )
                with st.expander("View retrieved source passages"):
                    for i, (chunk, score) in enumerate(results, start=1):
                        st.markdown(f"**Passage {i} — Page {chunk['page']} — relevance {score:.3f}**")
                        st.write(chunk["text"])
                        st.divider()
else:
    st.write("Upload a PDF to begin. Text-based PDFs work best; scanned PDFs need OCR, which is not included here.")
